import request from '@/utils/request'

export function getSO(params) {
  return request({
    url: 'spare-out',
    method: 'get',
    params
  })
}

export function addSO(data) {
  return request({
    url: 'spare-out/',
    method: 'post',
    data
  })
}

export function delSO(id) {
  return request({
    url: 'spare-out/' + id + '/',
    method: 'delete'
  })
}

export function editSO(id, data) {
  return request({
    url: 'spare-out/' + id + '/',
    method: 'put',
    data
  })
}
export function makeReport(id) {
  return request({
    url: 'make-report?id=' + id,
    method: 'post',
    responseType: 'blob'
  })
}
