import request from '@/utils/request'

export function getMW(params) {
  return request({
    url: 'middle-ware',
    method: 'get',
    params
  })
}

export function addMW(data) {
  return request({
    url: 'middle-ware/',
    method: 'post',
    data
  })
}

export function delMW(id) {
  return request({
    url: 'middle-ware/' + id + '/',
    method: 'delete'
  })
}

export function editMW(id, data) {
  return request({
    url: 'middle-ware/' + id + '/',
    method: 'put',
    data
  })
}
