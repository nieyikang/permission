import request from '@/utils/request'

export function getND(params) {
  return request({
    url: 'network',
    method: 'get',
    params
  })
}

export function addND(data) {
  return request({
    url: 'network/',
    method: 'post',
    data
  })
}

export function delND(id) {
  return request({
    url: 'network/' + id + '/',
    method: 'delete'
  })
}

export function editND(id, data) {
  return request({
    url: 'network/' + id + '/',
    method: 'put',
    data
  })
}

