import request from '@/utils/request'

export function importExcel(file, type) {
  var param = new FormData()
  param.append('file', file)
  return request({
    headers: { 'Content-Type': 'multipart/form-data' },
    url: 'import?type=' + type,
    method: 'post',
    data: param
  })
}

export function importHeader(type) {
  return request({
    url: 'import?type=' + type,
    method: 'get'
  })
}

