import request from '@/utils/request'

const qs = require('qs')
export function getUsers(params) {
  return request({
    url: 'users',
    method: 'get',
    params,
    // 数组传参
    paramsSerializer: function(params) {
      return qs.stringify(params, { arrayFormat: 'repeat' })
    }
  })
}
export function delUser(id) {
  return request({
    url: 'users/' + id + '/',
    method: 'delete'
  })
}
export function addUser(data) {
  return request({
    url: 'users/',
    method: 'post',
    data
  })
}
export function editUser(id, data) {
  return request({
    url: 'users/' + id + '/',
    method: 'put',
    data
  })
}
export function editUserPatch(id, data) {
  return request({
    url: 'users/' + id + '/',
    method: 'patch',
    data
  })
}
export function updatePasswd(id, data) {
  return request({
    url: 'users/' + id + '/change-passwd/',
    method: 'post',
    data
  })
}
