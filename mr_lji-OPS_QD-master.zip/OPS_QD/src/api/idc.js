import request from '@/utils/request'

export function getIdc(params) {
  return request({
    url: 'idc',
    method: 'get',
    params
  })
}

export function addIdc(data) {
  return request({
    url: 'idc/',
    method: 'post',
    data
  })
}

export function delIdc(id) {
  return request({
    url: 'idc/' + id + '/',
    method: 'delete'
  })
}

export function editIdc(id, data) {
  return request({
    url: 'idc/' + id + '/',
    method: 'put',
    data
  })
}
