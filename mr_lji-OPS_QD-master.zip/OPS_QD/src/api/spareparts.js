import request from '@/utils/request'

export function getSP(params) {
  return request({
    url: 'spare-parts',
    method: 'get',
    params
  })
}

export function addSP(data) {
  return request({
    url: 'spare-parts/',
    method: 'post',
    data
  })
}

export function delSP(id) {
  return request({
    url: 'spare-parts/' + id + '/',
    method: 'delete'
  })
}

export function editSP(id, data) {
  return request({
    url: 'spare-parts/' + id + '/',
    method: 'put',
    data
  })
}
