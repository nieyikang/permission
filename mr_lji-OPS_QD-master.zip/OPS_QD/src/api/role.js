import request from '@/utils/request'

export function getRoles(params) {
  return request({
    url: 'roles',
    method: 'get',
    params
  })
}
export function delRole(id) {
  return request({
    url: 'roles/' + id + '/',
    method: 'delete'
  })
}
export function addRole(data) {
  return request({
    url: 'roles/',
    method: 'post',
    data
  })
} export function editRole(id, data) {
  return request({
    url: 'roles/' + id + '/',
    method: 'put',
    data
  })
}
export function editRolePatch(id, data) {
  return request({
    url: 'roles/' + id + '/',
    method: 'patch',
    data
  })
}
