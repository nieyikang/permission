import request from '@/utils/request'

// 获取所有的权限树
export function getPermissionTree() {
  return request({
    url: 'permission/tree/',
    method: 'get'
  })
}

export function getPermissions(params) {
  return request({
    url: 'permissions/',
    method: 'get',
    params
  })
}

export function addPermission(data) {
  return request({
    url: 'permissions/',
    method: 'post',
    data
  })
}

export function delPermission(id) {
  return request({
    url: 'permissions/' + id + '/',
    method: 'delete'
  })
}

export function editPermission(id, data) {
  return request({
    url: 'permissions/' + id + '/',
    method: 'put',
    data
  })
}

export function retrieve(id) {
  return request({
    url: 'permissions/' + id + '/',
    method: 'get'
  })
}

export function save(id, data) {
  return request({
    url: 'permissions/' + id + '/',
    method: 'patch',
    data
  })
}
