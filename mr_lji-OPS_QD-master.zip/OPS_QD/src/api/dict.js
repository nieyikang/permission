import request from '@/utils/request'

export function getDicts(params) {
  return request({
    url: 'dict',
    method: 'get',
    params
  })
}

export function getDictByKey(key) {
  return request({
    url: 'dicts?&key=' + key,
    method: 'get'
  })
}

export function addDict(data) {
  return request({
    url: 'dict/',
    method: 'post',
    data
  })
}

export function delDict(id) {
  return request({
    url: 'dict/' + id + '/',
    method: 'delete'
  })
}

export function editDict(id, data) {
  return request({
    url: 'dict/' + id + '/',
    method: 'put',
    data
  })
}
export function getDictTree() {
  return request({
    url: 'dict/tree',
    method: 'get'
  })
}
