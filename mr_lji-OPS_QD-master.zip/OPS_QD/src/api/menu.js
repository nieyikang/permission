import request from '@/utils/request'

// 获取所有的菜单树
export function getMenuTree() {
  return request({
    url: 'menu/tree/',
    method: 'get'
  })
}
export function getMenus(params) {
  return request({
    url: 'menus/',
    method: 'get',
    params
  })
}

export function addMenu(data) {
  return request({
    url: 'menus/',
    method: 'post',
    data
  })
}

export function delMenu(id) {
  return request({
    url: 'menus/' + id + '/',
    method: 'delete'
  })
}

export function editMenu(id, data) {
  return request({
    url: 'menus/' + id + '/',
    method: 'put',
    data
  })
}

export function retrieve(id) {
  return request({
    url: 'menus/' + id + '/',
    method: 'get'
  })
}

export function save(id, data) {
  return request({
    url: 'menus/' + id + '/',
    method: 'patch',
    data
  })
}
