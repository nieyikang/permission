import request from '@/utils/request'

const qs = require('qs')
export function getServers(params) {
  return request({
    url: 'server',
    method: 'get',
    params,
    paramsSerializer: function(params) {
      return qs.stringify(params, { arrayFormat: 'repeat' })
    }
  })
}

export function addServer(data) {
  return request({
    url: 'server/',
    method: 'post',
    data
  })
}

export function uploadServer(params) {
  // const formData = new FormData(params)
  return request({
    headers: { 'Content-Type': 'multipart/form-data' },
    url: 'upload-server',
    method: 'post',
    params
  })
}

export function delServer(id) {
  return request({
    url: 'server/' + id + '/',
    method: 'delete'
  })
}

export function editServer(id, data) {
  return request({
    url: 'server/' + id + '/',
    method: 'put',
    data
  })
}
