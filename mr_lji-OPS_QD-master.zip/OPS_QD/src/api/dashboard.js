import request from '@/utils/request'

export function getDashboard(paramas) {
  return request({
    url: 'dashboard',
    method: 'get',
    paramas
  })
}
