import defaultSettings from '@/settings'

const title = defaultSettings.title || 'HzrsOps'

export default function getPageTitle(pageTitle) {
  if (pageTitle) {
    return `${pageTitle} - ${title}`
  }
  return `${title}`
}
