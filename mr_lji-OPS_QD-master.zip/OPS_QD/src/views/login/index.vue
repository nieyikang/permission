<template>
  <div class="login-container">
    <el-form
      ref="loginForm"
      :model="loginForm"
      :rules="loginRules"
      class="login-form"
      auto-complete="on"
      label-position="left"
    >
      <div class="title-container">
        <h3 class="title">OPS BETA</h3>
      </div>

      <el-form-item prop="username">
        <el-input
          ref="username"
          v-model="loginForm.username"
          size="small"
          placeholder="Username"
          name="username"
          type="text"
          tabindex="1"
          auto-complete="on"
        >
          <svg-icon slot="prefix" icon-class="user" /></el-input>
      </el-form-item>

      <el-form-item prop="password">
        <el-input
          :key="passwordType"
          ref="password"
          v-model="loginForm.password"
          size="small"
          :type="passwordType"
          placeholder="Password"
          name="password"
          tabindex="2"
          auto-complete="on"
          @keyup.enter.native="handleLogin"
        >
          <svg-icon slot="prefix" icon-class="password" /></el-input>
      </el-form-item>

      <el-button
        :loading="loading"
        type="primary"
        size="small"
        style="width:100%;margin-bottom:30px;"
        @click.native.prevent="handleLogin"
      >登录</el-button>

    </el-form>
    <div class="foot">
      <footer class="footer">
        <div class="footer-copyright">
          <span>HZRS</span>
          <span>NEUSOFT</span>
        </div>
        <div class="footer-copyright">建议使用CHROME浏览器 OPS V2 @2019</div>
      </footer>
    </div>
  </div>
</template>

<script>

export default {
  name: 'Login',
  data() {
    return {
      loginForm: {
        username: '',
        password: ''
      },
      loginRules: {
        username: [{ required: true, trigger: 'blur', message: '账户不能为空' }],
        password: [{ required: true, trigger: 'blur', message: '密码不能为空' }]
      },
      loading: false,
      passwordType: 'password',
      redirect: undefined
    }
  },
  watch: {
    $route: {
      handler: function(route) {
        this.redirect = route.query && route.query.redirect
      },
      immediate: true
    }
  },
  methods: {
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true
          this.$store.dispatch('user/login', this.loginForm).then(() => {
            this.$router.push({ path: this.redirect || '/' })
            this.loading = false
          }).catch(() => {
            this.loading = false
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
$bg: #f8f8f8;
$dark_gray: #889aa4;

.login-container {
  min-height: 100%;
  width: 100%;
  background-color: $bg;
  overflow: hidden;

  .login-form {
    position: absolute;
    top: 45%;
    left: 50%;
    width: 320px;
    height: 320px;
    box-shadow: rgba(0, 0, 0, 0.08) 0px 0px 100px;
    margin: -160px 0px 0px -160px;
    padding: 30px;
  }

  .tips {
    font-size: 14px;
    color: #fff;
    margin-bottom: 10px;

    span {
      &:first-of-type {
        margin-right: 16px;
      }
    }
  }

  .svg-container {
    padding: 6px 5px 6px 15px;
    color: $dark_gray;
    vertical-align: middle;
    width: 30px;
    display: inline-block;
  }
  .footer{
    margin: 48px 0 24px;
    padding: 0 16px;
    text-align: center;
  }
  .footer-copyright{
    color: rgba(0,0,0,.45);
    margin-bottom: 10px;
    font-size: 13px;
    span{
      margin-right:5px;
      margin-left:5px;
    }
  }
  .foot{
    position: absolute;
    width: 100%;
    bottom: 0px;
  }
  .title-container {
    text-align: center;
    cursor: pointer;
    margin-bottom: 24px;
    display: flex;
    justify-content: center;
    align-items: center;
    .title {
      vertical-align: text-bottom;
    font-size: 20px;
    text-transform: uppercase;
    display: inline-block;
    font-weight: 700;
    color: rgb(24, 144, 255);
    background-image: -webkit-gradient(linear, 37.2198% 34.5325%, 36.4257% 93.1782%, from(rgb(41, 205, 255)), to(rgb(10, 96, 255)), color-stop(0.37, rgb(20, 142, 255)));
    background-clip: text;
    -webkit-text-fill-color: transparent;
}

  }
}
</style>
