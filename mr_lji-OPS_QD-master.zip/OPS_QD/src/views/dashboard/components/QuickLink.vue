<template>
  <div>
    快捷链接
    <el-row>
      ZABBIX TOP 10 ISSES
    </el-row>
  </div>
</template>
<script>
export default {

}
</script>
