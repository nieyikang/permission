<template>
  <div class="app-container">
    <div class="filter-container">
      <el-input
        v-model="listQuery.search"
        placeholder="模糊搜索"
        style="width: 200px;"
        size="small"
        class="filter-item"
        @keyup.enter.native="handleFilter"
      ><i slot="prefix" class="el-input__icon el-icon-search" /></el-input>
      <el-button
        v-if="checkPermission(['admin','dict_create','dict_all'])"
        class="filter-item"
        size="small"
        style="margin-left: 10px;"
        type="primary"
        icon="el-icon-edit"
        @click="handleCreate"
      >新增</el-button>
    </div>
    <!--表格渲染-->
    <el-table v-if="checkPermission(['admin','dict_list','dict_all'])" v-loading="listLoading" :data="list" border size="small" row-key="id" default-expand-all empty-text="zh">
      <el-table-column prop="key" label="键KEY" align="left">
        <template slot-scope="scope">
          <span>{{ scope.row.key }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="value" label="值VALUE">
        <template slot-scope="scope">
          <span>{{ scope.row.value }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="desc" label="描述" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.desc }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="150px" align="center">
        <template slot-scope="scope">
          <el-button v-if="checkPermission(['admin','dict_edit','dict_all'])" :disabled="scope.row.pid=== null" type="primary" size="mini" @click="handleUpdate(scope.row)">
            编辑
          </el-button>
          <el-button v-if="checkPermission(['admin','dict_delete','dict_all'])" slot="reference" :disabled="scope.row.pid=== null" type="danger" size="mini" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="listQuery.page"
      :limit.sync="listQuery.limit"
      @pagination="getList"
    />
    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible" width="600px">
      <el-form ref="dataForm" :model="form" :rules="rules" size="small" label-width="80px">
        <el-form-item label="KEY键" prop="key">
          <el-input v-model="form.key" />
        </el-form-item>
        <el-form-item label="VALUE值" prop="value">
          <el-input v-model="form.value" />
        </el-form-item>
        <el-form-item label="描述" prop="desc">
          <el-input v-model="form.desc" />
        </el-form-item>
        <el-form-item label="父级字典">
          <treeselect v-model="form.pid" :options="dict" placeholder="选择父级菜单" style="width:200px" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取消</el-button>
        <el-button type="primary" @click="dialogStatus==='create'?createData():updateData()">确认</el-button>
      </div>
    </el-dialog>
  </div>

</template>

<script>
import Pagination from '@/components/Pagination'
import checkPermission from '@/utils/permission'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import { getDicts, delDict, addDict, editDict, getDictTree } from '@/api/dict'
export default {
  components: { Pagination, Treeselect },
  data() {
    return {
      list: null,
      total: 0,
      dialogFormVisible: false,
      dialogStatus: '',
      textMap: {
        update: '编辑',
        create: '新增'
      },
      listLoading: true,
      dict: [],
      form: {
        key: '',
        value: '',
        desc: '',
        pid: ''
      },
      rules: {
        name: [
          { required: true, message: '机房名称不能为空', trigger: 'blur' }
        ]
      },
      listQuery: {
        page: 1,
        limit: 10
      },
      columns: [
        {
          text: '名称',
          value: 'name'
        }
      ],
      menus: []
    }
  },
  created() {
    this.$nextTick(() => {
      this.getList()
      this.getTree()
    })
  },
  methods: {
    checkPermission,
    getTree() {
      getDictTree().then(response => {
        this.dict = response.data
      })
    },
    getList() {
      getDicts(this.listQuery).then(response => {
        this.list = response.results
        this.total = response.count
        this.listLoading = false
      })
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
      this.getTree()
    },
    handleDelete(row) {
      this.$confirm('此操作将永久删除此行, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        delDict(row.id).then(response => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
          const index = this.list.indexOf(row)
          this.list.splice(index, 1)
          this.handleFilter()
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    resetForm() {
      this.form = {
        key: '',
        value: '',
        desc: '',
        pid: undefined
      }
    },
    handleCreate() {
      this.resetForm()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
        // 清除
        this.$refs['dataForm'].resetFields()
      })
    },
    createData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          if (this.form.pid == null) {
            addDict(this.form).then(() => {
              this.resetForm()
              // this.list.unshift(this.temp)
              this.$message({
                type: 'success',
                message: '创建成功!'
              })
              this.dialogFormVisible = false
              this.handleFilter()
            })
            this.$message({
              type: 'danger',
              message: '你必须选择父级菜单!否则无法创建'
            })
          } else {
            addDict(this.form).then(() => {
              this.resetForm()
              // this.list.unshift(this.temp)
              this.$message({
                type: 'success',
                message: '创建成功!'
              })
              this.dialogFormVisible = false
              this.handleFilter()
            })
          }
        }
      })
    },
    handleUpdate(row) {
      this.resetForm()
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        // this.$refs['dataForm'].resetFields()
        this.$refs['dataForm'].clearValidate()
        this.form = { ...row }
      })
    },
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          editDict(this.form.id, this.form).then(() => {
            for (const v of this.list) {
              if (v.id === this.form.id) {
                const index = this.list.indexOf(v)
                this.list.splice(index, 1, this.form)
                break
              }
            }
            this.dialogFormVisible = false
            this.$message({
              type: 'success',
              message: '更新成功!'
            })
            this.handleFilter()
          })
        }
      })
    }
  }
}
</script>
