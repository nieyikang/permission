<template>
  <div class="app-container">
    <div class="filter-container">
      <el-input
        v-model="listQuery.search"
        placeholder="模糊搜索"
        style="width: 200px;"
        size="small"
        class="filter-item"
        @keyup.enter.native="handleFilter"
      ><i slot="prefix" class="el-input__icon el-icon-search" /></el-input>
      <div class="filter-item">
        <el-date-picker
          v-model="repDateSelect"
          type="daterange"
          unlink-panels
          range-separator="至"
          start-placeholder="更换开始日期"
          end-placeholder="更换结束日期"
          value-format="yyyy-MM-dd"
          size="small"
          @change="handleDateSelect"
        />
      </div>
      <el-button
        v-if="checkPermission(['admin','so_create','so_all'])"
        class="filter-item"
        size="small"
        style="margin-left: 10px;"
        type="primary"
        icon="el-icon-edit"
        @click="handleCreate"
      >新增</el-button>
      <el-button
        class="filter-item"
        size="small"
        style="margin-left: 10px;"
        type="info"
        icon="el-icon-refresh"
        @click="handleRefresh"
      >清空</el-button>
    </div>
    <!--表格渲染-->
    <el-table v-if="checkPermission(['admin','so_list','so_all'])" v-loading="listLoading" :data="list" border size="small" row-key="id">
      <el-table-column type="expand">
        <template slot-scope="props">
          <el-form label-position="left" inline class="table-expand">
            <el-form-item label="坏件SN">
              <span>{{ props.row.bad_sn }}</span>
            </el-form-item>
            <el-form-item label="坏件PN">
              <span>{{ props.row.bad_pn }}</span>
            </el-form-item>
            <el-form-item label="备件规格">
              <span>{{ props.row.SpareParts.size }}</span>
            </el-form-item>
            <el-form-item label="备件型号">
              <span>{{ props.row.SpareParts.model }}</span>
            </el-form-item>
            <el-form-item label="备件PN">
              <span>{{ props.row.SpareParts.pn }}</span>
            </el-form-item>
            <el-form-item label="创建时间">
              <span>{{ props.row.create_date | parseTime('{y}-{m}-{d} {h}:{i}') }}</span>
            </el-form-item>
            <el-form-item label="更新时间">
              <span>{{ props.row.update_date | parseTime('{y}-{m}-{d} {h}:{i}') }}</span>
            </el-form-item>
            <el-form-item label="备注">
              <span>{{ props.row.remarks }}</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="设备IP" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.ip }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="sn" label="设备SN" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.sn }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="model" label="设备型号" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.model }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="find_date" label="故障发现日期" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.find_date }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="rep_date" label="故障解决日期" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.rep_date }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="SpareParts.type" label="备件类型" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.SpareParts.type }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="SpareParts.sn" label="备件SN" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.SpareParts.sn }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="SpareParts.fixed" label="是否已修" align="center">
        <template slot-scope="scope">
          <el-tag :type="scope.row.fixed | statusFilter">
            {{ scope.row.fixed ? '已修':'未修' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="250px" align="center">
        <template slot-scope="scope">
          <el-button type="primary" size="mini" @click="handleReport(scope.row)">生成报告</el-button>
          <el-button v-if="checkPermission(['admin','so_edit','so_all'])" type="primary" size="mini" @click="handleUpdate(scope.row)">
            编辑
          </el-button>
          <el-button v-if="checkPermission(['admin','so_delete','so_all'])" slot="reference" type="danger" size="mini" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column></el-table>
    <!--分页组件-->
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="listQuery.page"
      :limit.sync="listQuery.limit"
      @pagination="getList"
    />
    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
      <el-form ref="dataForm" :model="form" :inline="true" :rules="rules" size="small" label-width="80px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="备件SN" prop="SpareParts">
              <el-select v-model="form.SpareParts" filterable placeholder="请选择">
                <el-option
                  v-for="item in splist"
                  :key="item.id"
                  :label="item.sn"
                  :value="item.id"
                />
              </el-select></el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="设备IP" prop="ip">
              <el-input v-model="form.ip" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="设备型号" prop="model">
              <el-input v-model="form.model" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="设备SN" prop="sn">
              <el-input v-model="form.sn" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="坏件SN" prop="bad_sn">
              <el-input v-model="form.bad_sn" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="坏件PN" prop="bad_pn">
              <el-input v-model="form.bad_pn" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="发现日期" prop="find_date">
              <el-date-picker
                v-model="form.find_date"
                type="date"
                placeholder="选择日期"
                format="yyyy 年 MM 月 dd 日"
                value-format="yyyy-MM-dd"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="更换日期" prop="rep_date">
              <el-date-picker
                v-model="form.rep_date"
                type="date"
                placeholder="选择日期"
                format="yyyy 年 MM 月 dd 日"
                value-format="yyyy-MM-dd"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="是否已修" prop="fixed">
              <el-switch
                v-model="form.fixed"
                active-color="#13ce66"
                inactive-color="#ff4949"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="备注" prop="remarks">
              <el-input v-model="form.remarks" type="textarea" autosize />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取消</el-button>
        <el-button type="primary" @click="dialogStatus==='create'?createData():updateData()">确认</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import Pagination from '@/components/Pagination'
import checkPermission from '@/utils/permission'
import { getSO, delSO, addSO, editSO, makeReport } from '@/api/spareout'
import { getSP } from '@/api/spareparts'
export default {
  components: { Pagination },
  filters: {
    statusFilter(status) {
      const statusMap = {
        true: 'success',
        false: 'danger'
      }
      return statusMap[status]
    }
  },
  data() {
    return {
      list: null,
      total: 0,
      dialogFormVisible: false,
      dialogStatus: '',
      textMap: {
        update: '编辑',
        create: '新增'
      },
      splist: [],
      listLoading: true,
      form: {
        sn: ''
      },
      type_dict: [],
      rules: {
        SpareParts: [
          { required: true, message: '请选择备件库内的备件', trigger: 'blur' }
        ],
        ip: [
          { required: true, message: '请输入设备的IP', trigger: 'blur' }
        ]
      },
      spId: '',
      repDateSelect: '',
      listQuery: {
        page: 1,
        limit: 10,
        search: undefined
      }
    }
  },
  created() {
    this.$nextTick(() => {
      this.getList()
      this.getSPList()
    })
  },
  methods: {
    checkPermission,
    getSPList() {
      getSP().then(response => {
        this.splist = response
      })
    },
    getList() {
      getSO(this.listQuery).then(response => {
        this.list = response.results
        this.total = response.count
        this.listLoading = false
        // Just to simulate the time of the request
        // setTimeout(() => {
        //   this.listLoading = false
        // }, 170)
      })
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },
    handleDelete(row) {
      this.$confirm('此操作将永久删除此行, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        delSO(row.id).then(response => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
          const index = this.list.indexOf(row)
          this.list.splice(index, 1)
          this.handleFilter()
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    resetForm() {
      this.spId = ''
      this.form = {
        sn: '',
        rep_date: '',
        model: '',
        remarks: '',
        ip: '',
        fixed: true,
        find_date: '',
        bad_sn: '',
        bad_pn: ''
      }
    },
    handleRefresh() {
      this.repDateSelect = ' '
      this.listQuery.rep_date_before = ''
      this.listQuery.rep_date_after = ''
      this.handleFilter()
    },
    handleCreate() {
      this.resetForm()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
        // 清除
        // this.$refs['dataForm'].resetFields()
      })
    },
    handleDateSelect() {
      this.listQuery.rep_date_after = this.repDateSelect[0]
      this.listQuery.rep_date_before - this.repDateSelect[1]
      this.handleFilter()
    },
    createData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          // this.form.SpareParts = this.spId
          addSO(this.form).then(() => {
            this.resetForm()
            // this.list.unshift(this.temp)
            this.$message({
              type: 'success',
              message: '创建成功!'
            })
            this.dialogFormVisible = false
            this.handleFilter()
          })
        }
      })
    },
    handleUpdate(row) {
      this.resetForm()
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        // this.$refs['dataForm'].resetFields()
        this.$refs['dataForm'].clearValidate()
        this.form = { ...row, SpareParts: row.SpareParts.id }
      })
    },
    handleReport(row) {
      makeReport(row.id).then(response => {
        const filename = row.ip + row.model + '.docx'
        const url = window.URL.createObjectURL(response)
        const link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        link.setAttribute('download', filename)
        document.body.appendChild(link)
        link.click()
        this.$message({
          type: 'success',
          message: '已成功生成服务报告'
        })
      })
    },
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          editSO(this.form.id, this.form).then(() => {
            for (const v of this.list) {
              if (v.id === this.form.id) {
                const index = this.list.indexOf(v)
                this.list.splice(index, 1, this.form)
                break
              }
            }
            this.dialogFormVisible = false
            this.$message({
              type: 'success',
              message: '更新成功!'
            })
            this.handleFilter()
          })
        }
      })
    }
  }
}
</script>
<style>
  .table-expand {
    font-size: 0;
  }
  .table-expand label {
    width: 90px;
    color: #99a9bf;
  }
  .table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 25%;
  }
</style>
