<template>
  <div class="head-container">
    <!-- 新增 -->
    <div style="display: inline-block;margin: 10px 10px;">
      <el-button
        class="filter-item"
        size="mini"
        type="primary"
        icon="el-icon-plus"
        @click="$refs.form.dialog = true;"
      >新增</el-button>
      <eForm ref="form" :is-add="true" />
    </div>

  </div>
</template>
<script>
import eForm from './form'
export default {
  components: { eForm },
  props: {
    roles: {
      type: Array,
      required: true
    },
    query: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      downloadLoading: false
    }
  }
}
</script>
