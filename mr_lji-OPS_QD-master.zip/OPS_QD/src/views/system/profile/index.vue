<template>
  <div class="app-container">
    <div v-if="user">
      <el-row :gutter="20" type="flex" justify="center">
        <el-col :span="6">
          <user-card :user="user" :getuser="getUser" style="height:100%" />
        </el-col>
        <el-col :span="18">
          <el-card>
            <account :user="user" />
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import userCard from './components/UserCard'
import account from './components/Account'
export default {
  name: 'Profile',
  components: { userCard, account },
  data() {
    return {
      user: {},
      activeTab: 'activity'
    }
  },
  computed: {
    ...mapGetters([
      'name',
      'id',
      'avatar',
      'roles',
      'mobile',
      'token',
      'email'
    ])
  },
  created() {
    this.getUser()
  },
  methods: {
    getUser() {
      this.user = {
        name: this.name,
        token: this.token,
        role: this.roles.join(' | '),
        mobile: this.mobile,
        email: this.email,
        id: this.id,
        avatar: this.avatar
      }
    }
  }
}
</script>
