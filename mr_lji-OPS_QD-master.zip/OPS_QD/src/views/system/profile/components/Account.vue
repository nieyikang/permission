<template>
  <el-form>
    <el-form-item label="姓名">
      <el-input v-model.trim="user.name" />
    </el-form-item>
    <el-form-item label="邮箱">
      <el-input v-model.trim="user.email" />
    </el-form-item>
    <el-form-item label="手机">
      <el-input v-model.trim="user.mobile" />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="submit">更新</el-button>
      <updatePassword />
    </el-form-item>
  </el-form>
</template>

<script>
import { editUserPatch } from '@/api/user'
import updatePassword from './updatePassword'
export default {
  components: { updatePassword },
  props: {
    user: {
      type: Object,
      default: () => {
        return {
          name: '',
          email: '',
          mobile: '',
          id: ''
        }
      }
    }
  },
  methods: {

    submit() {
      const data = { 'name': this.user.name, 'email': this.user.email, 'mobile': this.user.mobile }
      editUserPatch(this.user.id, data).then(response => {
        this.$message({
          type: 'success',
          message: '更新成功!'
        })
      })
    }
  }
}
</script>
