<template>
  <el-card>
    <div slot="header" class="clearfix">
      <span>个人中心</span>
    </div>
    <div class="user-profile">
      <div class="box-center">
        <pan-thumb :image="avatar" :height="'100px'" :width="'100px'" :hoverable="false">
          <div>Hello</div>
          {{ user.name }}
        </pan-thumb>
      </div>
      <div class="box-center">
        <div class="user-name text-center">{{ user.name }}</div>
        <div class="user-role text-center text-muted">{{ user.role }}</div>
      </div>
    </div>
    <div class="user-bio">
      <div class="user-education user-bio-section">
        <div class="user-bio-section-header"><svg-icon icon-class="education" /><span>Neusoft</span></div>
        <div class="user-bio-section-body">
          <div class="text-muted">
            系统运维
          </div>
          <my-upload
            v-model="show"
            field="img"
            :width="300"
            :height="300"
            url="api/upload-avatar"
            :params="params"
            :headers="headers"
            :img-format="imgFormat"
            @crop-success="cropSuccess"
            @crop-upload-success="cropUploadSuccess"
            @crop-upload-fail="cropUploadFail"
          />
          <el-button type="primary" icon="upload" style="position: absolute;bottom: 15px;" @click="show=true">
            更换头像
          </el-button>
        </div>
      </div>
    </div>
  </el-card>
</template>

<script>
import store from '@/store'
import { mapGetters } from 'vuex'
import myUpload from 'vue-image-crop-upload'
import PanThumb from '@/components/PanThumb'
export default {
  components: { PanThumb, myUpload },

  props: {
    user: {
      type: Object,
      default: () => {
        return {
          name: '',
          id: '',
          email: '',
          avatar: '',
          mobile: '',
          roles: ''
        }
      }
    }
  },
  data() {
    return {
      show: false,
      imgFormat: 'jpg',
      params: {
        token: this.user.token,
        name: 'avatar',
        imgFormat: ''
      },
      headers: {
        smail: '*_~'
      },
      imgDataUrl: '' // the datebase64 url of created image
    }
  },
  computed: {
    ...mapGetters([
      'avatar'
    ])
  },
  methods: {
    cropSuccess(imgDataUrl, field) {
      console.log('-------- crop success --------')
      this.imgDataUrl = imgDataUrl
    },
    cropUploadSuccess(jsonData, field) {
      this.$message({
        type: 'success',
        message: '头像更新成功!'
      })
      // 刷新vuex
      store.dispatch('user/getInfo')
    },
    cropUploadFail(status, field) {
      console.log('-------- upload fail --------')
      console.log(status)
      console.log('field: ' + field)
    }
  }
}
</script>

<style lang="scss" scoped>
 .box-center {
   margin: 0 auto;
   display: table;
 }

 .text-muted {
   color: #777;
 }

 .user-profile {
   .user-name {
     font-weight: bold;
   }

   .box-center {
     padding-top: 10px;
   }

   .user-role {
     padding-top: 10px;
     font-weight: 400;
     font-size: 14px;
   }

   .box-social {
     padding-top: 30px;

     .el-table {
       border-top: 1px solid #dfe6ec;
     }
   }

   .user-follow {
     padding-top: 20px;
   }
 }

 .user-bio {
   margin-top: 20px;
   color: #606266;

   span {
     padding-left: 4px;
   }

   .user-bio-section {
     font-size: 14px;
     padding: 15px 0;

     .user-bio-section-header {
       border-bottom: 1px solid #dfe6ec;
       padding-bottom: 10px;
       margin-bottom: 10px;
       font-weight: bold;
     }
   }
 }
</style>
