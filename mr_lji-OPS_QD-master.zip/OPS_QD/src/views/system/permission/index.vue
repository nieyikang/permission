<template>
  <div class="app-container">
    <div class="filter-container">
      <el-input
        v-model="listQuery.search"
        placeholder="模糊搜索"
        style="width: 200px;"
        size="small"
        class="filter-item"
        @keyup.enter.native="handleFilter"
      ><i slot="prefix" class="el-input__icon el-icon-search" /></el-input>
      <el-button
        v-if="checkPermission(['admin','permission_create','permission_all'])"
        class="filter-item"
        size="small"
        style="margin-left: 10px;"
        type="primary"
        icon="el-icon-edit"
        @click="handleCreate"
      >新增</el-button>
    </div>
    <!--表格渲染-->
    <el-table v-if="checkPermission(['admin','permission_list','permission_all'])" v-loading="listLoading" :data="list" border size="small" row-key="id">
      <el-table-column prop="name" label="名称" align="left" />
      <el-table-column prop="method" label="方法" align="center" />
      <el-table-column prop="desc" label="描述" align="center" />
      <el-table-column label="操作" width="150px" align="center">
        <template slot-scope="scope">
          <el-button v-if="checkPermission(['admin','permission_edit','permission_all'])" type="primary" size="mini" :disabled="scope.row.id === 1" @click="handleUpdate(scope.row)">
            编辑
          </el-button>
          <el-button v-if="checkPermission(['admin','permission_delete','permission_all'])" slot="reference" :disabled="scope.row.id === 1" type="danger" size="mini" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="listQuery.page"
      :limit.sync="listQuery.limit"
      @pagination="getList"
    />
    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible" width="600px">
      <el-form ref="dataForm" :model="form" :rules="rules" size="small" label-width="80px">
        <el-form-item label="名称" prop="name">
          <el-input v-model="form.name" placeholder="权限名称" style="width: 460px;" />
        </el-form-item>
        <el-form-item label="方法" prop="method">
          <el-input v-model.number="form.method" style="width: 460px;" />
        </el-form-item>
        <el-form-item label="描述" prop="desc">
          <el-input v-model="form.desc" style="width: 460px;" />
        </el-form-item>
        <el-form-item label="父级菜单">
          <treeselect v-model="form.pid" :options="permissions" placeholder="选择父级菜单" style="width:200px" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取消</el-button>
        <el-button type="primary" @click="dialogStatus==='create'?createData():updateData()">确认</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import Pagination from '@/components/Pagination'
import Treeselect from '@riophae/vue-treeselect'
import checkPermission from '@/utils/permission'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import { getPermissionTree, getPermissions, addPermission, delPermission, editPermission } from '@/api/permission'
export default {
  components: { Pagination, Treeselect },
  data() {
    return {
      list: null,
      total: 0,
      dialogFormVisible: false,
      dialogStatus: '',
      textMap: {
        update: '编辑',
        create: '新增'
      },
      listLoading: true,
      form: {
        id: '',
        name: '',
        desc: '',
        method: '',
        pid: null
      },
      rules: {
        is_show: [
          { required: true, message: '是否在导航栏显示', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请输入名称', trigger: 'blur' }
        ],
        sort: [
          { required: true, message: '请输入序号', trigger: 'blur', type: 'number' }
        ],
        is_frame: [
          { required: true, message: '请选择菜单类型', trigger: 'blur' }
        ]
      },
      listQuery: {
        page: 1,
        limit: 10,
        search: undefined
      },
      columns: [
        {
          text: '名称',
          value: 'name'
        }
      ],
      permissions: []
    }
  },
  created() {
    this.getList()
    this.getPermissions()
  },
  methods: {
    checkPermission,
    getList() {
      getPermissions(this.listQuery).then(response => {
        this.list = response.results
        this.total = response.count
        this.listLoading = false
        // // Just to simulate the time of the request
        // setTimeout(() => {
        //   this.listLoading = true
        // }, 1700)
      })
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
      this.getPermissions()
    },
    getPermissions() {
      getPermissionTree().then(res => {
        this.permissions = res.data
      })
    },
    handleDelete(row) {
      this.$confirm('此操作将永久删除此行, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        delPermission(row.id).then(response => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
          const index = this.list.indexOf(row)
          this.list.splice(index, 1)
          this.handleFilter()
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    resetForm() {
      this.form = {
        name: '',
        method: '',
        desc: ''
      }
    },
    handleCreate() {
      this.resetForm()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
        // // 清除
        // this.$refs['dataForm'].Fields()
      })
    },
    createData() {
      console.log(this.form)
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          addPermission(this.form).then(() => {
            this.resetForm()
            // this.list.unshift(this.temp)
            this.$message({
              type: 'success',
              message: '创建成功!'
            })
            this.dialogFormVisible = false
            this.handleFilter()
          })
        }
      })
    },
    handleUpdate(row) {
      this.resetForm()
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        // this.$refs['dataForm'].resetFields()
        this.$refs['dataForm'].clearValidate()
        this.form = { ...row }
      })
    },
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          editPermission(this.form.id, this.form).then(() => {
            for (const v of this.list) {
              if (v.id === this.form.id) {
                const index = this.list.indexOf(v)
                this.list.splice(index, 1, this.form)
                break
              }
            }
            this.dialogFormVisible = false
            this.$message({
              type: 'success',
              message: '编辑成功!'
            })
            this.handleFilter()
          })
        }
      })
    },
    selected(name) {
      this.form.icon = name
    }
  }
}
</script>
