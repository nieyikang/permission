const getters = {
  sidebar: state => state.app.sidebar,
  device: state => state.app.device,
  token: state => state.user.token,
  avatar: state => state.user.avatar,
  username: state => state.user.username,
  id: state => state.user.id,
  name: state => state.user.name,
  mobile: state => state.user.mobile,
  email: state => state.user.email,
  roles: state => state.user.roles,
  permission_routes: state => state.permission.routes,
  addRouters: state => state.permission.addRouters
}
export default getters
