const state = {
  dataList: []
}
const mutations = {
  CHART_DATA_LIST(state, data) {
    state.dataList = data
  }
}

const actions = {
  dataList({ commit }) {
    commit('CHART_DATA_LIST')
  }
}
export default {
  namespaced: true,
  state,
  mutations,
  actions
}
