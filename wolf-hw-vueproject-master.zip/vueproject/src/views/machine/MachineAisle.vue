/**
 * 基础菜单 货道信息管理
 */
<template>
  <div>基础菜单 货道信息管理</div>
</template>

<script>
export default {

}
</script>

<style>

</style>

 