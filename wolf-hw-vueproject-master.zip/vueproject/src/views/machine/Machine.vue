/**
 * 基础菜单 机器信息管理
 */
<template>
  <div>基础菜单 机器信息管理</div>
</template>

<script>
export default {

}
</script>

<style>

</style>

 