/**
* 404
*/ 
<template>
  <div class="page-404">
    <h1>404!</h1>
    <h2>Sorry, page not found</h2>
  </div>
</template>

<style scoped>
.page-404 {
  text-align: center;
}
.page-404 h1 {
  font-size: 98px;
  font-weight: 700;
  line-height: 150px;
  text-shadow: rgba(61, 61, 61, 0.3) 1px 1px, rgba(61, 61, 61, 0.2) 2px 2px,
    rgba(61, 61, 61, 0.3) 3px 3px;
}
.page-404 h2 {
  line-height: 30px;
  font-size: 30px;
}
</style>