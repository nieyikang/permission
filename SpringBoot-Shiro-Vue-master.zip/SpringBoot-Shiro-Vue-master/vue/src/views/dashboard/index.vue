<template>
  <div class="dashboard-container">
    <a href="https://github.com/Heeexy/SpringBoot-Shiro-Vue" target="_blank"><img style="margin: 40px"
      src="http://img.heeexy.com/github.png"></a>
  </div>
</template>
<script>
  export default {
    name: 'dashboard',
    data() {
      return {}
    },
  }
</script>
