from django.test import TestCase

# Create your tests here.
if 0:
    print('正确的')