from django.apps import AppConfig


class RightsConfig(AppConfig):
    name = 'power'
