from django.apps import AppConfig


class VueShopConfig(AppConfig):
    name = 'vue_shop'
