/**
 * Created by WebStorm.
 * User: nirongxu
 * Date: 2020/4/15
 * Description: 文件描述
 */
export default {
  // 账号密码登陆
  login: "/admin/user/login"
}
