<template>
    <div>
      <router-view></router-view>
    </div>
</template>

<script>
export default {
  name: "commerViews"
}
</script>

<style scoped>

</style>
