/**
 * Created by WebStorm.
 * User: nirongxu
 * Date: 2019-01-24
 * Description: 文件描述
 */
// 数据库信息配置
exports.sequelize = {
    // 数据库类型
    dialect: "mysql",
    // host
    host: "localhost",
    // 端口号
    port: "3306",
    // 用户名
    username: "root",
    // 密码
    password: "12345678",
    // 数据库名
    database: "nodePlatform"
};
