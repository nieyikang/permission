'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_HOST:'"http://www.code-js.com:7001"',
  VERSION_CONTROL: true  // 开启版本控制,缓存就得每次重新创建,build 的时候得不到优化
}
